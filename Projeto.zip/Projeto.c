#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>

FILE *arq;
char texto[255], ch;
char cliente[50], endereco[50], tel_cel[15], cpf[11], dat_nas[8];

char menu()
{
    system("cls");
    printf("\t\t\tSeja bem vindo! %s\n");
    fflush(stdin);
    printf("1-cadastrar novos clientes\n");
    printf("2-exibir dados\n");
    printf("3-alterar cadastro\n");
    printf("4-excluir cadastro\n");
    printf("5-relatorio de clientes\n");
    printf("0-sair\n");
    return getche();
}

void main()
{
  inicio:
      switch (menu())
      {
        case '1': //cadastro de clientes

            arq = fopen("cadastro.txt", "a");

            printf("Informe o nome do cliente:");
            scanf("%s\n", cliente);
            fprintf(arq, "%s\n", cliente);


            printf("informe o endereco: ");
            scanf("%s\n", endereco);
            fprintf(arq, "%s\n", endereco);


            printf("Data de nascimento: ");
            scanf("%s\n", dat_nas);
            fprintf(arq, "%s\n", dat_nas);


            printf("Telefone ou celular: ");
            scanf("%s\n", tel_cel);
            fprintf(arq, "%s\n", tel_cel);


            printf("Informe o cpf: ");
            scanf("%s\n", cpf);
            fprintf(arq, "%s\n", cpf);

            fclose(arq);
            break;

        case '2': //exibir dados
            arq = fopen("cadastro.txt", "r");

            printf("\n\n verificando arquivos\n");

            while (!feof(arq))
            {
                fgets(texto, 255, arq);
                printf("%s", texto);
            }
            fclose(arq);
            break;

        case '3':  //alterar cadastro
        break;

        case '4': //excluir cadastro
        break;

        case '5':
            arq = fopen("cadastro.txt", "r");

            printf("\n\n Relat�rio de clientes\n");

            while (!feof(arq))
            {
                fgets(texto, 255, arq);
                printf("%s", texto);
            }
            fclose(arq);
        break;
      }

}


